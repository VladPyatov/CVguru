__author__ = "VladislavPyatov"

from .reducer import Reducer
