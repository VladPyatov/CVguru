__author__ = "VladislavPyatov"

from .facedetector import FaceDetector
